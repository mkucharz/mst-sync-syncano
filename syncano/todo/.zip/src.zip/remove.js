"use strict";

var cov_2r90d579dn = function () {
  var path = "/Users/qk/code/mst-example-todomvc/syncano/todo/src/remove.ts",
      hash = "ea98290338b0b691a94869a2738834ad7b1561b5",
      Function = function () {}.constructor,
      global = new Function('return this')(),
      gcv = "__coverage__",
      coverageData = {
    path: "/Users/qk/code/mst-example-todomvc/syncano/todo/src/remove.ts",
    statementMap: {
      "0": {
        start: {
          line: 15,
          column: 18
        },
        end: {
          line: 15,
          column: 41
        }
      },
      "1": {
        start: {
          line: 16,
          column: 23
        },
        end: {
          line: 21,
          column: 6
        }
      },
      "2": {
        start: {
          line: 22,
          column: 4
        },
        end: {
          line: 22,
          column: 28
        }
      },
      "3": {
        start: {
          line: 24,
          column: 4
        },
        end: {
          line: 24,
          column: 26
        }
      },
      "4": {
        start: {
          line: 25,
          column: 4
        },
        end: {
          line: 25,
          column: 29
        }
      },
      "5": {
        start: {
          line: 26,
          column: 18
        },
        end: {
          line: 26,
          column: 39
        }
      },
      "6": {
        start: {
          line: 28,
          column: 4
        },
        end: {
          line: 30,
          column: 15
        }
      },
      "7": {
        start: {
          line: 35,
          column: 2
        },
        end: {
          line: 37,
          column: 3
        }
      },
      "8": {
        start: {
          line: 39,
          column: 2
        },
        end: {
          line: 39,
          column: 26
        }
      }
    },
    fnMap: {
      "0": {
        name: "(anonymous_0)",
        decl: {
          start: {
            line: 11,
            column: 2
          },
          end: {
            line: 11,
            column: 3
          }
        },
        loc: {
          start: {
            line: 14,
            column: 4
          },
          end: {
            line: 31,
            column: 3
          }
        },
        line: 14
      },
      "1": {
        name: "(anonymous_1)",
        decl: {
          start: {
            line: 34,
            column: 15
          },
          end: {
            line: 34,
            column: 16
          }
        },
        loc: {
          start: {
            line: 34,
            column: 22
          },
          end: {
            line: 40,
            column: 1
          }
        },
        line: 34
      }
    },
    branchMap: {},
    s: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0
    },
    f: {
      "0": 0,
      "1": 0
    },
    b: {},
    _coverageSchema: "43e27e138ebf9cfc5966b082cf9a028302ed4184"
  },
      coverage = global[gcv] || (global[gcv] = {});

  if (coverage[path] && coverage[path].hash === hash) {
    return coverage[path];
  }

  coverageData.hash = hash;
  return coverage[path] = coverageData;
}();

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var S = _interopRequireWildcard(require("@eyedea/syncano"));

var _syncano2 = require("./syncano");

var _todoStore = require("./todo-store");

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : {}; if (desc.get || desc.set) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } } newObj.default = obj; return newObj; } }

class Endpoint extends (S.Endpoint) {
  async run({
    data
  }, {
    args
  }) {
    cov_2r90d579dn.f[0]++;
    const store = (cov_2r90d579dn.s[0]++, _todoStore.TodoStoreModel.create());
    const connection = (cov_2r90d579dn.s[1]++, new _syncano2.Connector({
      appid: 'todos-app',
      modelName: 'todo-store',
      syncano: this.syncano,
      store
    }));
    cov_2r90d579dn.s[2]++;
    await connection.start();
    cov_2r90d579dn.s[3]++;
    this.logger.info(args);
    cov_2r90d579dn.s[4]++;
    this.logger.info({
      store
    });
    const {
      uid
    } = (cov_2r90d579dn.s[5]++, JSON.parse(args.node));
    cov_2r90d579dn.s[6]++;
    await data.todo.where('uid', uid).delete();
  }

}

var _default = ctx => {
  cov_2r90d579dn.f[1]++;
  cov_2r90d579dn.s[7]++;
  ctx.meta.metadata = {
    inputs: {}
  };
  cov_2r90d579dn.s[8]++;
  return new Endpoint(ctx);
};

exports.default = _default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9yZW1vdmUudHMiXSwibmFtZXMiOlsiRW5kcG9pbnQiLCJTIiwicnVuIiwiZGF0YSIsImFyZ3MiLCJzdG9yZSIsIlRvZG9TdG9yZU1vZGVsIiwiY3JlYXRlIiwiY29ubmVjdGlvbiIsIkNvbm5lY3RvciIsImFwcGlkIiwibW9kZWxOYW1lIiwic3luY2FubyIsInN0YXJ0IiwibG9nZ2VyIiwiaW5mbyIsInVpZCIsIkpTT04iLCJwYXJzZSIsIm5vZGUiLCJ0b2RvIiwid2hlcmUiLCJkZWxldGUiLCJjdHgiLCJtZXRhIiwibWV0YWRhdGEiLCJpbnB1dHMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBOztBQUNBOztBQUNBOzs7O0FBT0EsTUFBTUEsUUFBTixVQUF1QkMsQ0FBQyxDQUFDRCxRQUF6QixFQUFrQztBQUNoQyxRQUFNRSxHQUFOLENBQ0U7QUFBQ0MsSUFBQUE7QUFBRCxHQURGLEVBRUU7QUFBQ0MsSUFBQUE7QUFBRCxHQUZGLEVBR0U7QUFBQTtBQUNBLFVBQU1DLEtBQUssMkJBQUdDLDBCQUFlQyxNQUFmLEVBQUgsQ0FBWDtBQUNBLFVBQU1DLFVBQVUsMkJBQUcsSUFBSUMsbUJBQUosQ0FBYztBQUMvQkMsTUFBQUEsS0FBSyxFQUFFLFdBRHdCO0FBRS9CQyxNQUFBQSxTQUFTLEVBQUUsWUFGb0I7QUFHL0JDLE1BQUFBLE9BQU8sRUFBRSxLQUFLQSxPQUhpQjtBQUkvQlAsTUFBQUE7QUFKK0IsS0FBZCxDQUFILENBQWhCO0FBRkE7QUFRQSxVQUFNRyxVQUFVLENBQUNLLEtBQVgsRUFBTjtBQVJBO0FBVUEsU0FBS0MsTUFBTCxDQUFZQyxJQUFaLENBQWlCWCxJQUFqQjtBQVZBO0FBV0EsU0FBS1UsTUFBTCxDQUFZQyxJQUFaLENBQWlCO0FBQUNWLE1BQUFBO0FBQUQsS0FBakI7QUFDQSxVQUFNO0FBQUNXLE1BQUFBO0FBQUQsZ0NBQVFDLElBQUksQ0FBQ0MsS0FBTCxDQUFXZCxJQUFJLENBQUNlLElBQWhCLENBQVIsQ0FBTjtBQVpBO0FBY0EsVUFBTWhCLElBQUksQ0FBQ2lCLElBQUwsQ0FDSEMsS0FERyxDQUNHLEtBREgsRUFDVUwsR0FEVixFQUVITSxNQUZHLEVBQU47QUFHRDs7QUFyQitCOztlQXdCbkJDLEdBQUcsSUFBSTtBQUFBO0FBQUE7QUFDcEJBLEVBQUFBLEdBQUcsQ0FBQ0MsSUFBSixDQUFTQyxRQUFULEdBQW9CO0FBQ2xCQyxJQUFBQSxNQUFNLEVBQUU7QUFEVSxHQUFwQjtBQURvQjtBQUtwQixTQUFPLElBQUkxQixRQUFKLENBQWF1QixHQUFiLENBQVA7QUFDRCxDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgUyBmcm9tICdAZXllZGVhL3N5bmNhbm8nXG5pbXBvcnQge0Nvbm5lY3Rvcn0gZnJvbSAnLi9zeW5jYW5vJ1xuaW1wb3J0IHtUb2RvU3RvcmVNb2RlbH0gZnJvbSAnLi90b2RvLXN0b3JlJ1xuXG5pbnRlcmZhY2UgQXJncyB7XG4gIG5vZGU6IHN0cmluZ1xuICBwYXlsb2FkOiBzdHJpbmdcbn1cblxuY2xhc3MgRW5kcG9pbnQgZXh0ZW5kcyBTLkVuZHBvaW50IHtcbiAgYXN5bmMgcnVuKFxuICAgIHtkYXRhfTogUy5Db3JlLFxuICAgIHthcmdzfTogUy5Db250ZXh0PEFyZ3M+XG4gICkge1xuICAgIGNvbnN0IHN0b3JlID0gVG9kb1N0b3JlTW9kZWwuY3JlYXRlKClcbiAgICBjb25zdCBjb25uZWN0aW9uID0gbmV3IENvbm5lY3Rvcih7XG4gICAgICBhcHBpZDogJ3RvZG9zLWFwcCcsXG4gICAgICBtb2RlbE5hbWU6ICd0b2RvLXN0b3JlJyxcbiAgICAgIHN5bmNhbm86IHRoaXMuc3luY2FubyxcbiAgICAgIHN0b3JlLFxuICAgIH0pXG4gICAgYXdhaXQgY29ubmVjdGlvbi5zdGFydCgpXG5cbiAgICB0aGlzLmxvZ2dlci5pbmZvKGFyZ3MpXG4gICAgdGhpcy5sb2dnZXIuaW5mbyh7c3RvcmV9KVxuICAgIGNvbnN0IHt1aWR9ID0gSlNPTi5wYXJzZShhcmdzLm5vZGUpXG5cbiAgICBhd2FpdCBkYXRhLnRvZG9cbiAgICAgIC53aGVyZSgndWlkJywgdWlkKVxuICAgICAgLmRlbGV0ZSgpXG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgY3R4ID0+IHtcbiAgY3R4Lm1ldGEubWV0YWRhdGEgPSB7XG4gICAgaW5wdXRzOiB7fSxcbiAgfVxuXG4gIHJldHVybiBuZXcgRW5kcG9pbnQoY3R4KVxufVxuIl19