"use strict";

var cov_1oidcfvy73 = function () {
  var path = "/Users/qk/code/mst-example-todomvc/syncano/sync-state/src/sync.ts",
      hash = "93a2ef70b906dc98afee9160fecaa7d9d4a5cdb6",
      Function = function () {}.constructor,
      global = new Function('return this')(),
      gcv = "__coverage__",
      coverageData = {
    path: "/Users/qk/code/mst-example-todomvc/syncano/sync-state/src/sync.ts",
    statementMap: {
      "0": {
        start: {
          line: 21,
          column: 19
        },
        end: {
          line: 21,
          column: 23
        }
      },
      "1": {
        start: {
          line: 32,
          column: 8
        },
        end: {
          line: 32,
          column: 12
        }
      },
      "2": {
        start: {
          line: 34,
          column: 30
        },
        end: {
          line: 44,
          column: 5
        }
      },
      "3": {
        start: {
          line: 46,
          column: 4
        },
        end: {
          line: 46,
          column: 58
        }
      },
      "4": {
        start: {
          line: 49,
          column: 4
        },
        end: {
          line: 58,
          column: 5
        }
      },
      "5": {
        start: {
          line: 50,
          column: 6
        },
        end: {
          line: 55,
          column: 8
        }
      },
      "6": {
        start: {
          line: 57,
          column: 6
        },
        end: {
          line: 57,
          column: 87
        }
      },
      "7": {
        start: {
          line: 89,
          column: 4
        },
        end: {
          line: 91,
          column: 5
        }
      },
      "8": {
        start: {
          line: 90,
          column: 6
        },
        end: {
          line: 90,
          column: 47
        }
      },
      "9": {
        start: {
          line: 94,
          column: 4
        },
        end: {
          line: 94,
          column: 45
        }
      },
      "10": {
        start: {
          line: 95,
          column: 4
        },
        end: {
          line: 95,
          column: 48
        }
      },
      "11": {
        start: {
          line: 96,
          column: 4
        },
        end: {
          line: 98,
          column: 5
        }
      },
      "12": {
        start: {
          line: 97,
          column: 6
        },
        end: {
          line: 97,
          column: 48
        }
      },
      "13": {
        start: {
          line: 101,
          column: 4
        },
        end: {
          line: 104,
          column: 6
        }
      },
      "14": {
        start: {
          line: 106,
          column: 17
        },
        end: {
          line: 113,
          column: 5
        }
      },
      "15": {
        start: {
          line: 116,
          column: 4
        },
        end: {
          line: 121,
          column: 5
        }
      },
      "16": {
        start: {
          line: 117,
          column: 6
        },
        end: {
          line: 120,
          column: 7
        }
      },
      "17": {
        start: {
          line: 123,
          column: 31
        },
        end: {
          line: 123,
          column: 81
        }
      },
      "18": {
        start: {
          line: 124,
          column: 27
        },
        end: {
          line: 126,
          column: 38
        }
      },
      "19": {
        start: {
          line: 128,
          column: 4
        },
        end: {
          line: 129,
          column: 94
        }
      },
      "20": {
        start: {
          line: 159,
          column: 4
        },
        end: {
          line: 159,
          column: 26
        }
      },
      "21": {
        start: {
          line: 160,
          column: 4
        },
        end: {
          line: 160,
          column: 59
        }
      },
      "22": {
        start: {
          line: 164,
          column: 22
        },
        end: {
          line: 164,
          column: 39
        }
      }
    },
    fnMap: {
      "0": {
        name: "(anonymous_0)",
        decl: {
          start: {
            line: 17,
            column: 2
          },
          end: {
            line: 17,
            column: 3
          }
        },
        loc: {
          start: {
            line: 20,
            column: 4
          },
          end: {
            line: 156,
            column: 3
          }
        },
        line: 20
      },
      "1": {
        name: "(anonymous_1)",
        decl: {
          start: {
            line: 158,
            column: 2
          },
          end: {
            line: 158,
            column: 3
          }
        },
        loc: {
          start: {
            line: 158,
            column: 31
          },
          end: {
            line: 161,
            column: 3
          }
        },
        line: 158
      },
      "2": {
        name: "(anonymous_2)",
        decl: {
          start: {
            line: 164,
            column: 15
          },
          end: {
            line: 164,
            column: 16
          }
        },
        loc: {
          start: {
            line: 164,
            column: 22
          },
          end: {
            line: 164,
            column: 39
          }
        },
        line: 164
      }
    },
    branchMap: {
      "0": {
        loc: {
          start: {
            line: 28,
            column: 6
          },
          end: {
            line: 28,
            column: 20
          }
        },
        type: "default-arg",
        locations: [{
          start: {
            line: 28,
            column: 15
          },
          end: {
            line: 28,
            column: 20
          }
        }],
        line: 28
      },
      "1": {
        loc: {
          start: {
            line: 29,
            column: 6
          },
          end: {
            line: 29,
            column: 22
          }
        },
        type: "default-arg",
        locations: [{
          start: {
            line: 29,
            column: 18
          },
          end: {
            line: 29,
            column: 22
          }
        }],
        line: 29
      },
      "2": {
        loc: {
          start: {
            line: 31,
            column: 6
          },
          end: {
            line: 31,
            column: 24
          }
        },
        type: "default-arg",
        locations: [{
          start: {
            line: 31,
            column: 19
          },
          end: {
            line: 31,
            column: 24
          }
        }],
        line: 31
      },
      "3": {
        loc: {
          start: {
            line: 89,
            column: 4
          },
          end: {
            line: 91,
            column: 5
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 89,
            column: 4
          },
          end: {
            line: 91,
            column: 5
          }
        }, {
          start: {
            line: 89,
            column: 4
          },
          end: {
            line: 91,
            column: 5
          }
        }],
        line: 89
      },
      "4": {
        loc: {
          start: {
            line: 89,
            column: 8
          },
          end: {
            line: 89,
            column: 52
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 89,
            column: 8
          },
          end: {
            line: 89,
            column: 26
          }
        }, {
          start: {
            line: 89,
            column: 30
          },
          end: {
            line: 89,
            column: 52
          }
        }],
        line: 89
      },
      "5": {
        loc: {
          start: {
            line: 96,
            column: 4
          },
          end: {
            line: 98,
            column: 5
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 96,
            column: 4
          },
          end: {
            line: 98,
            column: 5
          }
        }, {
          start: {
            line: 96,
            column: 4
          },
          end: {
            line: 98,
            column: 5
          }
        }],
        line: 96
      },
      "6": {
        loc: {
          start: {
            line: 96,
            column: 8
          },
          end: {
            line: 96,
            column: 58
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 96,
            column: 8
          },
          end: {
            line: 96,
            column: 26
          }
        }, {
          start: {
            line: 96,
            column: 30
          },
          end: {
            line: 96,
            column: 58
          }
        }],
        line: 96
      },
      "7": {
        loc: {
          start: {
            line: 116,
            column: 4
          },
          end: {
            line: 121,
            column: 5
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 116,
            column: 4
          },
          end: {
            line: 121,
            column: 5
          }
        }, {
          start: {
            line: 116,
            column: 4
          },
          end: {
            line: 121,
            column: 5
          }
        }],
        line: 116
      },
      "8": {
        loc: {
          start: {
            line: 124,
            column: 27
          },
          end: {
            line: 126,
            column: 38
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 125,
            column: 8
          },
          end: {
            line: 125,
            column: 53
          }
        }, {
          start: {
            line: 126,
            column: 8
          },
          end: {
            line: 126,
            column: 38
          }
        }],
        line: 124
      },
      "9": {
        loc: {
          start: {
            line: 124,
            column: 27
          },
          end: {
            line: 124,
            column: 61
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 124,
            column: 27
          },
          end: {
            line: 124,
            column: 42
          }
        }, {
          start: {
            line: 124,
            column: 46
          },
          end: {
            line: 124,
            column: 61
          }
        }],
        line: 124
      }
    },
    s: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0,
      "10": 0,
      "11": 0,
      "12": 0,
      "13": 0,
      "14": 0,
      "15": 0,
      "16": 0,
      "17": 0,
      "18": 0,
      "19": 0,
      "20": 0,
      "21": 0,
      "22": 0
    },
    f: {
      "0": 0,
      "1": 0,
      "2": 0
    },
    b: {
      "0": [0],
      "1": [0],
      "2": [0],
      "3": [0, 0],
      "4": [0, 0],
      "5": [0, 0],
      "6": [0, 0],
      "7": [0, 0],
      "8": [0, 0],
      "9": [0, 0]
    },
    _coverageSchema: "d34fc3e6b8297bcde183f5492bcb8fcb36775295"
  },
      coverage = global[gcv] || (global[gcv] = {});

  if (coverage[path] && coverage[path].hash === hash) {
    return coverage[path];
  }

  coverageData.hash = hash;
  return coverage[path] = coverageData;
}();

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var S = _interopRequireWildcard(require("@eyedea/syncano"));

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : {}; if (desc.get || desc.set) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } } newObj.default = obj; return newObj; } }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

class Endpoint extends (S.Endpoint) {
  async run({
    data,
    channel,
    response
  }, {
    args,
    meta
  }) {
    cov_1oidcfvy73.f[0]++;
    const {
      user
    } = (cov_1oidcfvy73.s[0]++, meta);
    const {
      appid,
      entity,
      action,
      payload,
      tid,
      secret = (cov_1oidcfvy73.b[0][0]++, false),
      latestTid = (cov_1oidcfvy73.b[1][0]++, null),
      fromSocket,
      syncObject = (cov_1oidcfvy73.b[2][0]++, false)
    } = (cov_1oidcfvy73.s[1]++, args);
    const transactionParams = (cov_1oidcfvy73.s[2]++, {
      appid,
      entity,
      action,
      payload,
      tid,
      secret,
      latestTid,
      fromSocket,
      syncObject
    });
    cov_1oidcfvy73.s[3]++;
    this.logger.info('New transaction', transactionParams);
    let lock;
    cov_1oidcfvy73.s[4]++;

    try {
      cov_1oidcfvy73.s[5]++;
      lock = await this.syncano.data.lock.create({
        lockID: `${appid}-${entity}`,
        appid,
        entity,
        latestTid: tid
      });
    } catch (err) {
      cov_1oidcfvy73.s[6]++;
      lock = await this.syncano.data.lock.where('lockID', `${appid}-${entity}`).first();
    } // let query = this.syncano.data.lock
    //   .where('appid', appid)
    //   .where('entity', entity)
    //
    // const userId = user ? user.id : null
    //
    // if (secret === true && userId === null) {
    //   throw new Error('If creating a secret object you must be logged in')
    // }
    // if (userId !== null && secret === true) {
    //   query = query.where('user', userId)
    // }
    // let lock = await query.list()
    // if (lock.length === 0) {
    //   // Create new lock if it doesn't exist
    //   let lockParams = {
    //     appid,
    //     entity,
    //     latestTid: tid,
    //   }
    //   if (secret === true) {
    //     lockParams = {...lockParams, user: userId}
    //   }
    //   await this.syncano.data.lock.create(lockParams)
    //   lock = await query.first()
    // }
    // // lock = lock[0]


    cov_1oidcfvy73.s[7]++;

    if ((cov_1oidcfvy73.b[4][0]++, latestTid === null) && (cov_1oidcfvy73.b[4][1]++, lock.latestTid !== tid)) {
      cov_1oidcfvy73.b[3][0]++;
      cov_1oidcfvy73.s[8]++;
      throw new Error('Please provide last id');
    } else {
      cov_1oidcfvy73.b[3][1]++;
    } // Throw error if you are trying to apply patch with mismatched `latestTid`


    cov_1oidcfvy73.s[9]++;
    this.logger.debug('Transaction matching');
    cov_1oidcfvy73.s[10]++;
    this.logger.debug(latestTid, lock.latestTid);
    cov_1oidcfvy73.s[11]++;

    if ((cov_1oidcfvy73.b[6][0]++, latestTid !== null) && (cov_1oidcfvy73.b[6][1]++, lock.latestTid !== latestTid)) {
      cov_1oidcfvy73.b[5][0]++;
      cov_1oidcfvy73.s[12]++;
      throw new Error('Transaction id mismatch');
    } else {
      cov_1oidcfvy73.b[5][1]++;
    } // Update lock ID


    cov_1oidcfvy73.s[13]++;
    await this.syncano.data.lock.update(lock.id, {
      expected_revision: lock.revision,
      latestTid: tid
    });
    let params = (cov_1oidcfvy73.s[14]++, {
      appid,
      entity,
      action,
      payload,
      tid,
      syncObject // if secret is true make this user owned object

    });
    cov_1oidcfvy73.s[15]++;

    if (secret === true) {
      cov_1oidcfvy73.b[7][0]++;
      cov_1oidcfvy73.s[16]++;
      params = _objectSpread({}, params, {
        user: userId
      });
    } else {
      cov_1oidcfvy73.b[7][1]++;
    }

    const createdTransaction = (cov_1oidcfvy73.s[17]++, await this.syncano.data.transaction.create(params));
    const messagesString = (cov_1oidcfvy73.s[18]++, (cov_1oidcfvy73.b[9][0]++, secret === true) && (cov_1oidcfvy73.b[9][1]++, userId !== null) ? (cov_1oidcfvy73.b[8][0]++, `user_websocket.${appid}-${entity}.${userId}`) : (cov_1oidcfvy73.b[8][1]++, `websocket.${appid}-${entity}`));
    cov_1oidcfvy73.s[19]++;
    this.syncano.channel.publish(messagesString, {
      appid,
      entity,
      action,
      payload,
      syncObject,
      tid,
      id: createdTransaction.id,
      latestTid
    }); // const transPayload = JSON.parse(args.payload)
    // if (transPayload.syncObject && !fromSocket) {
    //   // event.emit(`${entity}.${action}`, {payload, latestTid: tid})
    //   const params = {
    //     entity: entity,
    //     appid: 'app',
    //     action: action,
    //     tid: crypto.randomBytes(Math.ceil(5)).toString('hex').slice(0, 5),
    //     latestTid: tid,
    //     fromSocket: true,
    //     syncObject: true
    //   }
    //   const args = transPayload.args
    //   try {
    //     const {temp} = await socket.get('openweathermap/get-temperature', {city: args.city})
    //     params.payload = JSON.stringify({args, data: {temp}, state: 'ready', syncObject: transPayload.syncObject})
    //   } catch (err) {
    //     console.log(err, err.data.message)
    //     params.payload =
    // JSON.stringify({args, data: {}, state: 'error', error: err.data.message, syncObject: transPayload.syncObject})
    //   }
    //   console.log(params)
    //   await createTransaction(params)
    // }
    // return response.json(createdTransaction)
  }

  endpointDidCatch(err) {
    cov_1oidcfvy73.f[1]++;
    cov_1oidcfvy73.s[20]++;
    this.logger.error(err);
    cov_1oidcfvy73.s[21]++;
    this.syncano.response.json({
      message: err.message
    }, 409);
  }

}

var _default = ctx => {
  cov_1oidcfvy73.f[2]++;
  cov_1oidcfvy73.s[22]++;
  return new Endpoint(ctx);
};

exports.default = _default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9zeW5jLnRzIl0sIm5hbWVzIjpbIkVuZHBvaW50IiwiUyIsInJ1biIsImRhdGEiLCJjaGFubmVsIiwicmVzcG9uc2UiLCJhcmdzIiwibWV0YSIsInVzZXIiLCJhcHBpZCIsImVudGl0eSIsImFjdGlvbiIsInBheWxvYWQiLCJ0aWQiLCJzZWNyZXQiLCJsYXRlc3RUaWQiLCJmcm9tU29ja2V0Iiwic3luY09iamVjdCIsInRyYW5zYWN0aW9uUGFyYW1zIiwibG9nZ2VyIiwiaW5mbyIsImxvY2siLCJzeW5jYW5vIiwiY3JlYXRlIiwibG9ja0lEIiwiZXJyIiwid2hlcmUiLCJmaXJzdCIsIkVycm9yIiwiZGVidWciLCJ1cGRhdGUiLCJpZCIsImV4cGVjdGVkX3JldmlzaW9uIiwicmV2aXNpb24iLCJwYXJhbXMiLCJ1c2VySWQiLCJjcmVhdGVkVHJhbnNhY3Rpb24iLCJ0cmFuc2FjdGlvbiIsIm1lc3NhZ2VzU3RyaW5nIiwicHVibGlzaCIsImVuZHBvaW50RGlkQ2F0Y2giLCJlcnJvciIsImpzb24iLCJtZXNzYWdlIiwiY3R4Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBOzs7Ozs7OztBQWVBLE1BQU1BLFFBQU4sVUFBdUJDLENBQUMsQ0FBQ0QsUUFBekIsRUFBa0M7QUFDaEMsUUFBTUUsR0FBTixDQUNFO0FBQUNDLElBQUFBLElBQUQ7QUFBT0MsSUFBQUEsT0FBUDtBQUFnQkMsSUFBQUE7QUFBaEIsR0FERixFQUVFO0FBQUNDLElBQUFBLElBQUQ7QUFBT0MsSUFBQUE7QUFBUCxHQUZGLEVBR0U7QUFBQTtBQUNBLFVBQU07QUFBQ0MsTUFBQUE7QUFBRCxnQ0FBU0QsSUFBVCxDQUFOO0FBQ0EsVUFBTTtBQUNKRSxNQUFBQSxLQURJO0FBRUpDLE1BQUFBLE1BRkk7QUFHSkMsTUFBQUEsTUFISTtBQUlKQyxNQUFBQSxPQUpJO0FBS0pDLE1BQUFBLEdBTEk7QUFNSkMsTUFBQUEsTUFBTSw4QkFBRyxLQUFILENBTkY7QUFPSkMsTUFBQUEsU0FBUyw4QkFBRyxJQUFILENBUEw7QUFRSkMsTUFBQUEsVUFSSTtBQVNKQyxNQUFBQSxVQUFVLDhCQUFHLEtBQUg7QUFUTixnQ0FVRlgsSUFWRSxDQUFOO0FBWUEsVUFBTVksaUJBQWlCLDJCQUFHO0FBQ3hCVCxNQUFBQSxLQUR3QjtBQUV4QkMsTUFBQUEsTUFGd0I7QUFHeEJDLE1BQUFBLE1BSHdCO0FBSXhCQyxNQUFBQSxPQUp3QjtBQUt4QkMsTUFBQUEsR0FMd0I7QUFNeEJDLE1BQUFBLE1BTndCO0FBT3hCQyxNQUFBQSxTQVB3QjtBQVF4QkMsTUFBQUEsVUFSd0I7QUFTeEJDLE1BQUFBO0FBVHdCLEtBQUgsQ0FBdkI7QUFkQTtBQTBCQSxTQUFLRSxNQUFMLENBQVlDLElBQVosQ0FBaUIsaUJBQWpCLEVBQW9DRixpQkFBcEM7QUFFQSxRQUFJRyxJQUFKO0FBNUJBOztBQTZCQSxRQUFJO0FBQUE7QUFDRkEsTUFBQUEsSUFBSSxHQUFHLE1BQU0sS0FBS0MsT0FBTCxDQUFhbkIsSUFBYixDQUFrQmtCLElBQWxCLENBQXVCRSxNQUF2QixDQUE4QjtBQUN6Q0MsUUFBQUEsTUFBTSxFQUFHLEdBQUVmLEtBQU0sSUFBR0MsTUFBTyxFQURjO0FBRXpDRCxRQUFBQSxLQUZ5QztBQUd6Q0MsUUFBQUEsTUFIeUM7QUFJekNLLFFBQUFBLFNBQVMsRUFBRUY7QUFKOEIsT0FBOUIsQ0FBYjtBQU1ELEtBUEQsQ0FPRSxPQUFPWSxHQUFQLEVBQVk7QUFBQTtBQUNaSixNQUFBQSxJQUFJLEdBQUcsTUFBTSxLQUFLQyxPQUFMLENBQWFuQixJQUFiLENBQWtCa0IsSUFBbEIsQ0FBdUJLLEtBQXZCLENBQTZCLFFBQTdCLEVBQXdDLEdBQUVqQixLQUFNLElBQUdDLE1BQU8sRUFBMUQsRUFBNkRpQixLQUE3RCxFQUFiO0FBQ0QsS0F0Q0QsQ0F3Q0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFuRUE7O0FBcUVBLFFBQUksMkJBQUFaLFNBQVMsS0FBSyxJQUFkLGdDQUFzQk0sSUFBSSxDQUFDTixTQUFMLEtBQW1CRixHQUF6QyxDQUFKLEVBQWtEO0FBQUE7QUFBQTtBQUNoRCxZQUFNLElBQUllLEtBQUosQ0FBVSx3QkFBVixDQUFOO0FBQ0QsS0FGRDtBQUFBO0FBQUEsS0FyRUEsQ0F5RUE7OztBQXpFQTtBQTBFQSxTQUFLVCxNQUFMLENBQVlVLEtBQVosQ0FBa0Isc0JBQWxCO0FBMUVBO0FBMkVBLFNBQUtWLE1BQUwsQ0FBWVUsS0FBWixDQUFrQmQsU0FBbEIsRUFBNkJNLElBQUksQ0FBQ04sU0FBbEM7QUEzRUE7O0FBNEVBLFFBQUksMkJBQUFBLFNBQVMsS0FBSyxJQUFkLGdDQUFzQk0sSUFBSSxDQUFDTixTQUFMLEtBQW1CQSxTQUF6QyxDQUFKLEVBQXdEO0FBQUE7QUFBQTtBQUN0RCxZQUFNLElBQUlhLEtBQUosQ0FBVSx5QkFBVixDQUFOO0FBQ0QsS0FGRDtBQUFBO0FBQUEsS0E1RUEsQ0FnRkE7OztBQWhGQTtBQWlGQSxVQUFNLEtBQUtOLE9BQUwsQ0FBYW5CLElBQWIsQ0FBa0JrQixJQUFsQixDQUF1QlMsTUFBdkIsQ0FBOEJULElBQUksQ0FBQ1UsRUFBbkMsRUFBdUM7QUFDM0NDLE1BQUFBLGlCQUFpQixFQUFFWCxJQUFJLENBQUNZLFFBRG1CO0FBRTNDbEIsTUFBQUEsU0FBUyxFQUFFRjtBQUZnQyxLQUF2QyxDQUFOO0FBS0EsUUFBSXFCLE1BQU0sNEJBQUc7QUFDWHpCLE1BQUFBLEtBRFc7QUFFWEMsTUFBQUEsTUFGVztBQUdYQyxNQUFBQSxNQUhXO0FBSVhDLE1BQUFBLE9BSlc7QUFLWEMsTUFBQUEsR0FMVztBQU1YSSxNQUFBQSxVQU5XLENBU2I7O0FBVGEsS0FBSCxDQUFWO0FBdEZBOztBQWdHQSxRQUFJSCxNQUFNLEtBQUssSUFBZixFQUFxQjtBQUFBO0FBQUE7QUFDbkJvQixNQUFBQSxNQUFNLHFCQUNEQSxNQURDO0FBRUoxQixRQUFBQSxJQUFJLEVBQUUyQjtBQUZGLFFBQU47QUFJRCxLQUxEO0FBQUE7QUFBQTs7QUFPQSxVQUFNQyxrQkFBa0IsNEJBQUcsTUFBTSxLQUFLZCxPQUFMLENBQWFuQixJQUFiLENBQWtCa0MsV0FBbEIsQ0FBOEJkLE1BQTlCLENBQXFDVyxNQUFyQyxDQUFULENBQXhCO0FBQ0EsVUFBTUksY0FBYyw0QkFBRywyQkFBQXhCLE1BQU0sS0FBSyxJQUFYLGdDQUFtQnFCLE1BQU0sS0FBSyxJQUE5QiwrQkFDbEIsa0JBQWlCMUIsS0FBTSxJQUFHQyxNQUFPLElBQUd5QixNQUFPLEVBRHpCLCtCQUVsQixhQUFZMUIsS0FBTSxJQUFHQyxNQUFPLEVBRlYsQ0FBSCxDQUFwQjtBQXhHQTtBQTRHQSxTQUFLWSxPQUFMLENBQWFsQixPQUFiLENBQXFCbUMsT0FBckIsQ0FBNkJELGNBQTdCLEVBQ0U7QUFBQzdCLE1BQUFBLEtBQUQ7QUFBUUMsTUFBQUEsTUFBUjtBQUFnQkMsTUFBQUEsTUFBaEI7QUFBd0JDLE1BQUFBLE9BQXhCO0FBQWlDSyxNQUFBQSxVQUFqQztBQUE2Q0osTUFBQUEsR0FBN0M7QUFBa0RrQixNQUFBQSxFQUFFLEVBQUVLLGtCQUFrQixDQUFDTCxFQUF6RTtBQUE2RWhCLE1BQUFBO0FBQTdFLEtBREYsRUE1R0EsQ0ErR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDRDs7QUFFRHlCLEVBQUFBLGdCQUFnQixDQUFDZixHQUFELEVBQWE7QUFBQTtBQUFBO0FBQzNCLFNBQUtOLE1BQUwsQ0FBWXNCLEtBQVosQ0FBa0JoQixHQUFsQjtBQUQyQjtBQUUzQixTQUFLSCxPQUFMLENBQWFqQixRQUFiLENBQXNCcUMsSUFBdEIsQ0FBMkI7QUFBQ0MsTUFBQUEsT0FBTyxFQUFFbEIsR0FBRyxDQUFDa0I7QUFBZCxLQUEzQixFQUFtRCxHQUFuRDtBQUNEOztBQWpKK0I7O2VBb0puQkMsR0FBRyxJQUFJO0FBQUE7QUFBQTtBQUFBLGFBQUk1QyxRQUFKLENBQWE0QyxHQUFiO0FBQWlCLEMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBTIGZyb20gJ0BleWVkZWEvc3luY2FubydcbmltcG9ydCBjcnlwdG8gZnJvbSAnY3J5cHRvJ1xuXG5pbnRlcmZhY2UgQXJncyB7XG4gIGFwcGlkOiBzdHJpbmdcbiAgZW50aXR5OiBzdHJpbmdcbiAgYWN0aW9uOiBzdHJpbmdcbiAgcGF5bG9hZDogc3RyaW5nXG4gIHRpZDogc3RyaW5nXG4gIHNlY3JldDogYm9vbGVhblxuICBsYXRlc3RUaWQ6IHN0cmluZ1xuICBmcm9tU29ja2V0OiBib29sZWFuXG4gIHN5bmNPYmplY3Q6IGJvb2xlYW5cbn1cblxuY2xhc3MgRW5kcG9pbnQgZXh0ZW5kcyBTLkVuZHBvaW50IHtcbiAgYXN5bmMgcnVuKFxuICAgIHtkYXRhLCBjaGFubmVsLCByZXNwb25zZX06IFMuQ29yZSxcbiAgICB7YXJncywgbWV0YX06IFMuQ29udGV4dDxBcmdzPlxuICApIHtcbiAgICBjb25zdCB7dXNlcn0gPSBtZXRhXG4gICAgY29uc3Qge1xuICAgICAgYXBwaWQsXG4gICAgICBlbnRpdHksXG4gICAgICBhY3Rpb24sXG4gICAgICBwYXlsb2FkLFxuICAgICAgdGlkLFxuICAgICAgc2VjcmV0ID0gZmFsc2UsXG4gICAgICBsYXRlc3RUaWQgPSBudWxsLFxuICAgICAgZnJvbVNvY2tldCxcbiAgICAgIHN5bmNPYmplY3QgPSBmYWxzZSxcbiAgICB9ID0gYXJnc1xuXG4gICAgY29uc3QgdHJhbnNhY3Rpb25QYXJhbXMgPSB7XG4gICAgICBhcHBpZCxcbiAgICAgIGVudGl0eSxcbiAgICAgIGFjdGlvbixcbiAgICAgIHBheWxvYWQsXG4gICAgICB0aWQsXG4gICAgICBzZWNyZXQsXG4gICAgICBsYXRlc3RUaWQsXG4gICAgICBmcm9tU29ja2V0LFxuICAgICAgc3luY09iamVjdCxcbiAgICB9XG5cbiAgICB0aGlzLmxvZ2dlci5pbmZvKCdOZXcgdHJhbnNhY3Rpb24nLCB0cmFuc2FjdGlvblBhcmFtcylcblxuICAgIGxldCBsb2NrXG4gICAgdHJ5IHtcbiAgICAgIGxvY2sgPSBhd2FpdCB0aGlzLnN5bmNhbm8uZGF0YS5sb2NrLmNyZWF0ZSh7XG4gICAgICAgIGxvY2tJRDogYCR7YXBwaWR9LSR7ZW50aXR5fWAsXG4gICAgICAgIGFwcGlkLFxuICAgICAgICBlbnRpdHksXG4gICAgICAgIGxhdGVzdFRpZDogdGlkLFxuICAgICAgfSlcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGxvY2sgPSBhd2FpdCB0aGlzLnN5bmNhbm8uZGF0YS5sb2NrLndoZXJlKCdsb2NrSUQnLCBgJHthcHBpZH0tJHtlbnRpdHl9YCkuZmlyc3QoKVxuICAgIH1cblxuICAgIC8vIGxldCBxdWVyeSA9IHRoaXMuc3luY2Fuby5kYXRhLmxvY2tcbiAgICAvLyAgIC53aGVyZSgnYXBwaWQnLCBhcHBpZClcbiAgICAvLyAgIC53aGVyZSgnZW50aXR5JywgZW50aXR5KVxuICAgIC8vXG4gICAgLy8gY29uc3QgdXNlcklkID0gdXNlciA/IHVzZXIuaWQgOiBudWxsXG4gICAgLy9cbiAgICAvLyBpZiAoc2VjcmV0ID09PSB0cnVlICYmIHVzZXJJZCA9PT0gbnVsbCkge1xuICAgIC8vICAgdGhyb3cgbmV3IEVycm9yKCdJZiBjcmVhdGluZyBhIHNlY3JldCBvYmplY3QgeW91IG11c3QgYmUgbG9nZ2VkIGluJylcbiAgICAvLyB9XG4gICAgLy8gaWYgKHVzZXJJZCAhPT0gbnVsbCAmJiBzZWNyZXQgPT09IHRydWUpIHtcbiAgICAvLyAgIHF1ZXJ5ID0gcXVlcnkud2hlcmUoJ3VzZXInLCB1c2VySWQpXG4gICAgLy8gfVxuXG4gICAgLy8gbGV0IGxvY2sgPSBhd2FpdCBxdWVyeS5saXN0KClcbiAgICAvLyBpZiAobG9jay5sZW5ndGggPT09IDApIHtcbiAgICAvLyAgIC8vIENyZWF0ZSBuZXcgbG9jayBpZiBpdCBkb2Vzbid0IGV4aXN0XG4gICAgLy8gICBsZXQgbG9ja1BhcmFtcyA9IHtcbiAgICAvLyAgICAgYXBwaWQsXG4gICAgLy8gICAgIGVudGl0eSxcbiAgICAvLyAgICAgbGF0ZXN0VGlkOiB0aWQsXG4gICAgLy8gICB9XG4gICAgLy8gICBpZiAoc2VjcmV0ID09PSB0cnVlKSB7XG4gICAgLy8gICAgIGxvY2tQYXJhbXMgPSB7Li4ubG9ja1BhcmFtcywgdXNlcjogdXNlcklkfVxuICAgIC8vICAgfVxuICAgIC8vICAgYXdhaXQgdGhpcy5zeW5jYW5vLmRhdGEubG9jay5jcmVhdGUobG9ja1BhcmFtcylcbiAgICAvLyAgIGxvY2sgPSBhd2FpdCBxdWVyeS5maXJzdCgpXG4gICAgLy8gfVxuICAgIC8vIC8vIGxvY2sgPSBsb2NrWzBdXG5cbiAgICBpZiAobGF0ZXN0VGlkID09PSBudWxsICYmIGxvY2subGF0ZXN0VGlkICE9PSB0aWQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignUGxlYXNlIHByb3ZpZGUgbGFzdCBpZCcpXG4gICAgfVxuXG4gICAgLy8gVGhyb3cgZXJyb3IgaWYgeW91IGFyZSB0cnlpbmcgdG8gYXBwbHkgcGF0Y2ggd2l0aCBtaXNtYXRjaGVkIGBsYXRlc3RUaWRgXG4gICAgdGhpcy5sb2dnZXIuZGVidWcoJ1RyYW5zYWN0aW9uIG1hdGNoaW5nJylcbiAgICB0aGlzLmxvZ2dlci5kZWJ1ZyhsYXRlc3RUaWQsIGxvY2subGF0ZXN0VGlkKVxuICAgIGlmIChsYXRlc3RUaWQgIT09IG51bGwgJiYgbG9jay5sYXRlc3RUaWQgIT09IGxhdGVzdFRpZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdUcmFuc2FjdGlvbiBpZCBtaXNtYXRjaCcpXG4gICAgfVxuXG4gICAgLy8gVXBkYXRlIGxvY2sgSURcbiAgICBhd2FpdCB0aGlzLnN5bmNhbm8uZGF0YS5sb2NrLnVwZGF0ZShsb2NrLmlkLCB7XG4gICAgICBleHBlY3RlZF9yZXZpc2lvbjogbG9jay5yZXZpc2lvbixcbiAgICAgIGxhdGVzdFRpZDogdGlkLFxuICAgIH0pXG5cbiAgICBsZXQgcGFyYW1zID0ge1xuICAgICAgYXBwaWQsXG4gICAgICBlbnRpdHksXG4gICAgICBhY3Rpb24sXG4gICAgICBwYXlsb2FkLFxuICAgICAgdGlkLFxuICAgICAgc3luY09iamVjdCxcbiAgICB9XG5cbiAgICAvLyBpZiBzZWNyZXQgaXMgdHJ1ZSBtYWtlIHRoaXMgdXNlciBvd25lZCBvYmplY3RcbiAgICBpZiAoc2VjcmV0ID09PSB0cnVlKSB7XG4gICAgICBwYXJhbXMgPSB7XG4gICAgICAgIC4uLnBhcmFtcyxcbiAgICAgICAgdXNlcjogdXNlcklkLFxuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IGNyZWF0ZWRUcmFuc2FjdGlvbiA9IGF3YWl0IHRoaXMuc3luY2Fuby5kYXRhLnRyYW5zYWN0aW9uLmNyZWF0ZShwYXJhbXMpXG4gICAgY29uc3QgbWVzc2FnZXNTdHJpbmcgPSBzZWNyZXQgPT09IHRydWUgJiYgdXNlcklkICE9PSBudWxsXG4gICAgICA/IGB1c2VyX3dlYnNvY2tldC4ke2FwcGlkfS0ke2VudGl0eX0uJHt1c2VySWR9YFxuICAgICAgOiBgd2Vic29ja2V0LiR7YXBwaWR9LSR7ZW50aXR5fWBcblxuICAgIHRoaXMuc3luY2Fuby5jaGFubmVsLnB1Ymxpc2gobWVzc2FnZXNTdHJpbmcsXG4gICAgICB7YXBwaWQsIGVudGl0eSwgYWN0aW9uLCBwYXlsb2FkLCBzeW5jT2JqZWN0LCB0aWQsIGlkOiBjcmVhdGVkVHJhbnNhY3Rpb24uaWQsIGxhdGVzdFRpZH0pXG5cbiAgICAvLyBjb25zdCB0cmFuc1BheWxvYWQgPSBKU09OLnBhcnNlKGFyZ3MucGF5bG9hZClcbiAgICAvLyBpZiAodHJhbnNQYXlsb2FkLnN5bmNPYmplY3QgJiYgIWZyb21Tb2NrZXQpIHtcbiAgICAvLyAgIC8vIGV2ZW50LmVtaXQoYCR7ZW50aXR5fS4ke2FjdGlvbn1gLCB7cGF5bG9hZCwgbGF0ZXN0VGlkOiB0aWR9KVxuICAgIC8vICAgY29uc3QgcGFyYW1zID0ge1xuICAgIC8vICAgICBlbnRpdHk6IGVudGl0eSxcbiAgICAvLyAgICAgYXBwaWQ6ICdhcHAnLFxuICAgIC8vICAgICBhY3Rpb246IGFjdGlvbixcbiAgICAvLyAgICAgdGlkOiBjcnlwdG8ucmFuZG9tQnl0ZXMoTWF0aC5jZWlsKDUpKS50b1N0cmluZygnaGV4Jykuc2xpY2UoMCwgNSksXG4gICAgLy8gICAgIGxhdGVzdFRpZDogdGlkLFxuICAgIC8vICAgICBmcm9tU29ja2V0OiB0cnVlLFxuICAgIC8vICAgICBzeW5jT2JqZWN0OiB0cnVlXG4gICAgLy8gICB9XG4gICAgLy8gICBjb25zdCBhcmdzID0gdHJhbnNQYXlsb2FkLmFyZ3NcbiAgICAvLyAgIHRyeSB7XG4gICAgLy8gICAgIGNvbnN0IHt0ZW1wfSA9IGF3YWl0IHNvY2tldC5nZXQoJ29wZW53ZWF0aGVybWFwL2dldC10ZW1wZXJhdHVyZScsIHtjaXR5OiBhcmdzLmNpdHl9KVxuICAgIC8vICAgICBwYXJhbXMucGF5bG9hZCA9IEpTT04uc3RyaW5naWZ5KHthcmdzLCBkYXRhOiB7dGVtcH0sIHN0YXRlOiAncmVhZHknLCBzeW5jT2JqZWN0OiB0cmFuc1BheWxvYWQuc3luY09iamVjdH0pXG4gICAgLy8gICB9IGNhdGNoIChlcnIpIHtcbiAgICAvLyAgICAgY29uc29sZS5sb2coZXJyLCBlcnIuZGF0YS5tZXNzYWdlKVxuICAgIC8vICAgICBwYXJhbXMucGF5bG9hZCA9XG4gICAgLy8gSlNPTi5zdHJpbmdpZnkoe2FyZ3MsIGRhdGE6IHt9LCBzdGF0ZTogJ2Vycm9yJywgZXJyb3I6IGVyci5kYXRhLm1lc3NhZ2UsIHN5bmNPYmplY3Q6IHRyYW5zUGF5bG9hZC5zeW5jT2JqZWN0fSlcbiAgICAvLyAgIH1cbiAgICAvLyAgIGNvbnNvbGUubG9nKHBhcmFtcylcbiAgICAvLyAgIGF3YWl0IGNyZWF0ZVRyYW5zYWN0aW9uKHBhcmFtcylcbiAgICAvLyB9XG4gICAgLy8gcmV0dXJuIHJlc3BvbnNlLmpzb24oY3JlYXRlZFRyYW5zYWN0aW9uKVxuICB9XG5cbiAgZW5kcG9pbnREaWRDYXRjaChlcnI6IEVycm9yKSB7XG4gICAgdGhpcy5sb2dnZXIuZXJyb3IoZXJyKVxuICAgIHRoaXMuc3luY2Fuby5yZXNwb25zZS5qc29uKHttZXNzYWdlOiBlcnIubWVzc2FnZX0sIDQwOSlcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBjdHggPT4gbmV3IEVuZHBvaW50KGN0eClcbiJdfQ==